﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades5
{
    public class Deposito
    {
        public Producto[] productos;
       
        

        public Deposito():this(3)
        {
            
        }

        public Deposito(int cant)
        {
            this.productos = new Producto[cant];
           
        }

        public static Producto[] operator +(Deposito a, Deposito b)
        {
            Producto[] auxProductos = new Producto[4];
            Producto auxP;
            int index = 0;
            int indice;

            foreach (Producto i in a.productos)
            {

                if ((auxProductos == i) == -1)
                {

                    auxProductos[index] = i;
                    
                    if(index == 3)
                    {
                        break;
                    }
                    else
                    {
                        index++;
                    }
                }
                else
                {

                    indice = (auxProductos == i);
                    auxP = new Producto(i.nombre, auxProductos[indice].stock + i.stock);
                    auxProductos[indice] = auxP;

                }

            }

            foreach (Producto i in b.productos)
            {

                if ((auxProductos == i) == -1)
                {

                    auxProductos[index] = i;
                    index++;

                }
                else
                {

                    indice = (auxProductos == i);
                    auxP = new Producto(i.nombre, auxProductos[indice].stock + i.stock);
                    auxProductos[indice] = auxP;

                }

            }

            return auxProductos;

        }





        public Producto[] OrdenadoPorStock()
        {
            
             List<Producto> listaProd = this.productos.ToList();

            listaProd.Sort(Producto.OrdenarPorStock);

            return listaProd.ToArray();

        }

        public Producto[] OrdenadoPorNombre()
        {
            List<Producto> listaProd = this.productos.ToList();
            listaProd = listaProd.OrderBy(x => x.nombre).ToList();

            return listaProd.ToArray();

        }


       


    }
}
