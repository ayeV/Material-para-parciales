using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using System.Xml;
namespace Entidades2
{
 public static class Extensora
  {
    public static bool SerializarXML(this IInterface interfaz,string path)
    {
     return interfaz.SerializarXml(path);
    }

    public static bool DeserializarXML(this IInterface interfaz, string path)
    {
      return interfaz.DeserializarXml(path);
    }

  }
}
