using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades2
{
    [Serializable]
    public class Goma : Utiles
    {
        #region Atributos
        protected bool _soloLapiz;
        #endregion

        #region Propiedades
        public override string Marca
        {
            get { return this._marca; }
            set { this._marca = value; }
        }

        public override double Precio
        {
            get { return this._precio; }
            set { this._precio = value; }
        }
        #endregion

        #region Constructor

        public Goma() : base()
        {

        }
        public Goma(string marca, double precio, bool soloLapiz) : base(precio, marca)
        {
            this._soloLapiz = soloLapiz;
        }
        #endregion

        #region Metodo
        public override string ToString()
        {
            return this.UtilesToString();
        }

        protected override string UtilesToString()
        {
            return string.Format(base.UtilesToString() + "Solo Lapiz: {0}\n", this._soloLapiz);
        }
        #endregion
    }
}
