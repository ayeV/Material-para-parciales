using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using System.Xml;
namespace Entidades2
{
    [Serializable]
    public class Lapicera : Utiles, IInterface
    {
        #region Atributos
        protected string _color;
        protected string _trazo;
        #endregion

        #region Propiedades
        public override string Marca
        {
            get { return this._marca; }
            set { this._marca = value; }
        }

        public override double Precio
        {
            get { return this._precio; }
            set { this._precio = value; }
        }

        public string Color
        {
            get { return this._color; }
            set { this._color = value; }

        }
        public string Trazo
        {
            get { return this._trazo; }
            set { this._trazo = value; }
        }
        #endregion

        #region Constructor

        public Lapicera() : base()
        {

        }

        public Lapicera(string marca, double precio, string color, string trazo) : base(precio, marca)
        {
            this._color = color;
            this._trazo = trazo;
        }
        #endregion

        #region Metodo
        public override string ToString()
        {

            return this.UtilesToString();

        }
        protected override string UtilesToString()
        {
           
         return string.Format(base.UtilesToString() + "Color: {0}---Trazo {1}\n", this._color, this._trazo);
           
            
        }

        public bool SerializarXml(string path)
        {
            bool retorno = true;
            XmlSerializer xSerializer = new XmlSerializer(typeof(Lapicera));

            try
            {
                using (XmlTextWriter xml = new XmlTextWriter(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "/" + path, null))
                {
                    xSerializer.Serialize(xml, this);

                }
            }
            catch (Exception)
            {


                retorno = false;
            }
            return retorno;

        }


      public  bool DeserializarXml(string path)
        {
            bool retorno = true;
            XmlSerializer xSerializer = new XmlSerializer(typeof(Lapicera));

            try
            {
                using (XmlTextReader xml = new XmlTextReader(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "/" + path))
                {
                    xSerializer.Deserialize(xml);

                }

            }
            catch (Exception e)
            {


                retorno = false;
            }

            return retorno;
        }




        #endregion
    }
}
