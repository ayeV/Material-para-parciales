using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Threading;
namespace Entidades2
{


    public delegate void DelegadoPrecio();
    public delegate string DelegadoLeerArchivo();

    [Serializable]
    public class Cartuchera<T> : IInterface where T : Utiles
    {
        #region Atributos
        protected string _marca;
        protected byte _capacidad;
        protected List<T> _elementos;
        public event DelegadoPrecio EventoPrecio;
       

        #endregion

        public List<T> Elementos
        {
            get { return this._elementos; }
            set { this._elementos = value; }
        }

        public byte Capacidad
        {
            get { return this._capacidad; }
            set { this._capacidad = value; }
        }
        public string Marca
        {
            get { return this._marca; }
            set { this._marca = value; }
        }

        #region Constructores



        public Cartuchera()
        {
            this._elementos = new List<T>();
           
        }


        public Cartuchera(byte capacidad, string marca) : this()
        {
            this._capacidad = capacidad;
            this._marca = marca;
        }
        #endregion

        #region Operador
        public static implicit operator byte(Cartuchera<T> cartuchera)
        {
            return cartuchera._capacidad;
        }
        #endregion

        #region Metodos
        public void Add(T elemento)
        {
            foreach (T item in this._elementos)
            {
                if (item.Equals(elemento))
                {
                    break;
                }

            }

            if (this._elementos.Count < this._capacidad)
            {
                this._elementos.Add(elemento);
            }
            else
            {
                throw new CartucheraLlenaException("Cartuchera llena");
            }


        }

        public bool Remove(T elemento)
        {
            bool retorno = false;
            foreach (T item in this._elementos)
            {
                if (item.Equals(elemento))
                {
                    this._elementos.Remove(elemento);
                    retorno = true;
                    break;
                }
            }

            return retorno;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("------CARTUCHERA-----");
            sb.AppendFormat("Marca: {0}---Capacidad:{1}  ", this._marca, this._capacidad);
            sb.AppendLine("\nElementos: \n");
            foreach (T item in this._elementos)
            {
                sb.AppendLine(item.ToString());

            }

            return sb.ToString();
        }

        public bool SerializarXml(string path)
        {
            bool retorno = true;
            XmlSerializer xSerializer = new XmlSerializer(typeof(Cartuchera<T>));

            try
            {
                using (XmlTextWriter xml = new XmlTextWriter(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "/" + path, Encoding.UTF8))
                {
                    xSerializer.Serialize(xml, (Cartuchera<T>)this);

                }
            }
            catch (Exception e)
            {


                retorno = false;
            }
            return retorno;

        }





        public bool DeserializarXml(string path)
        {
            bool retorno = true;
            XmlSerializer xSerializer = new XmlSerializer(typeof(Cartuchera<T>));

            try
            {
                using (XmlTextReader xml = new XmlTextReader(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "/" + path))
                {
                    xSerializer.Deserialize(xml);

                }

            }
            catch (Exception e)
            {


                retorno = false;
            }

            return retorno;
        }

        public double CalcularPrecio()
        {
            double precioTotal = 0;
            foreach (T item in this._elementos)
            {
                precioTotal += item.Precio * this._elementos.Count;

            }
            if (precioTotal > 53)
            {
                this.EventoPrecio();
            }

            return precioTotal;
        }



        public static List<Utiles> ObtenerBD()
        {
            SqlConnection conexion = new SqlConnection(Properties.Settings.Default.Conexion);
            SqlCommand comando = new SqlCommand();
            comando.CommandText = "SELECT * FROM Utiles.dbo.elementos";
            comando.CommandType = System.Data.CommandType.Text;
            comando.Connection = conexion;
            List<Utiles> utiles = new List<Utiles>();

            try
            {
                conexion.Open();
                SqlDataReader lector = comando.ExecuteReader();

                while (lector.Read())
                {
                    if ((byte)lector[6] == 1)
                    {

                        utiles.Add(new Lapicera(lector.GetString(1), double.Parse(lector.GetSqlSingle(2).ToString()), lector.GetString(3), lector.GetString(4)));
                    }
                    else
                    {
                        bool esTrue = true;
                        if (lector.GetByte(5) != 1)
                        {
                            esTrue = false;
                        }
                        utiles.Add(new Goma(lector.GetString(1), double.Parse(lector.GetSqlSingle(2).ToString()), esTrue));
                    }




                    Console.WriteLine("{0} {1} {2} {3}\n", lector[0], lector[1], lector[2], lector[3]);

                }
                conexion.Close();

            }
            catch (Exception e)
            {

                throw;
            }



            return utiles;

        }

        public void Imprimir_Txt()
        {
            try
            {
                using (var sw = new StreamWriter(String.Format("{0}/cartuchera_{1}.txt", Environment.CurrentDirectory, typeof(T).Name)))
                {
                    sw.Write(string.Format("Fecha y hora: {0} Util que genero el evento: {1}", DateTime.Now.ToString("G"),typeof(T).Name));
                }

            }
            catch (Exception e)
            {
                throw;
            }

        }

        public static string LeerTxt()
        {
            string datos = "";
            try
            {
                using (StreamReader sr = new StreamReader(String.Format("{0}/cartuchera_{1}.txt", Environment.CurrentDirectory, typeof(T).Name)))
                {
                  datos +=  sr.ReadToEnd();
                }
            }
            catch (Exception e)
            {

                throw;
            }
            return datos;
        }

        #endregion
    }
}
