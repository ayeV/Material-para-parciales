﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades4
{
   public class Durazno :Fruta
    {
        protected int _cantPelusa;

        public override bool TieneCarozo
        {
            get { return true; }
           
        }

        public int CantPelusa
        {
            get { return this._cantPelusa; }
            set { this._cantPelusa = value; }
        }



        public string Nombre { get { return "Durazno"; }  }

        public Durazno(string color, double peso, int pelusa) :base(color, peso)
        {
            this._cantPelusa = pelusa;
        }
        public override string ToString()
        {
            return string.Format(base.FrutaToString() + "Cant pelusa: {0}", this._cantPelusa);
        }
    }
}
