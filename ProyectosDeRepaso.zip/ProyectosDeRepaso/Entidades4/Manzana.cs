﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace Entidades4
{
   public class Manzana:Fruta, ISerializar,IDeserializar
    {
        protected string _provinciaOrigen;

        public string Nombre
        { get { return "Manzana"; }  }

        public override bool TieneCarozo
        { get { return true; } }

        public string Provincia
        {
            get { return this._provinciaOrigen; }
            set { this._provinciaOrigen = value; }
        }

        public Manzana()
        {

        }
        public Manzana(string color, double peso, string provincia) :base(color,peso)
        {
            this._provinciaOrigen = provincia;
        }

        public override string ToString()
        {
            return string.Format(base.FrutaToString() + "Provincia: {0}", this._provinciaOrigen);
        }

        public bool Xml(string path)
        {
            bool retorno = true;
            XmlSerializer xser = new XmlSerializer(typeof(Manzana));
            try
            {
                using (XmlTextWriter var = new XmlTextWriter(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "/" + path, Encoding.UTF8))
                {
                    xser.Serialize(var, this);
                }
            }
            catch (Exception e)
            {
                retorno = false;
                throw;
            }

            return retorno;
        }

        bool IDeserializar.Xml(string path, out Fruta datos)
        {
            bool retorno = true;
            XmlSerializer serializer = new XmlSerializer(typeof(Manzana));
            try
            {
                using (XmlTextReader xml = new XmlTextReader(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "/" + path))
                {
                    datos = (Manzana)serializer.Deserialize(xml);
                }
            }
            catch (Exception e )
            {
                datos = default(Manzana);
                retorno = false;
                throw;
            }

            return retorno;
        }
    }
}
