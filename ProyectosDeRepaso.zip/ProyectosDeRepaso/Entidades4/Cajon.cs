﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using System.Xml;
using System.IO;

namespace Entidades4
{
    public delegate void DelegadoPrecio(double precio);
    public class Cajon<T> :ISerializar  where T : Fruta
    {
        protected int _capacidad;
        protected double _precioUnitario;
        protected List<T> _elementos;
        public event DelegadoPrecio EventoPrecio;

        public List<T> Elementos
        { get { return this._elementos; }
          set { this._elementos = value; }
        }

        public int Capacidad
        {
            get { return this._capacidad; }
            set { this._capacidad = value; }
        }

        public double PrecioTotal
        {
            get
            {
                double precioTotal = 0;
                precioTotal = this._elementos.Count * this._precioUnitario;
                if(precioTotal >55)
                {
                    this.EventoPrecio(precioTotal);
                }
                return precioTotal;
            }
        }

        public Cajon()
        {
            this._elementos = new List<T>();

        }
        public Cajon(int capacidad) : this()
        {
            this._capacidad = capacidad;
        }
        public Cajon( double precio, int capacidad) : this(capacidad)
        {
            this._precioUnitario = precio;
        }


        public static Cajon<T> operator +(Cajon<T> c, T frutas)
        {
            foreach ( T item in c._elementos)
            {
                if(item.Equals(frutas))
                {
                    break;
                }
            }

            if(c._elementos.Count <= c._capacidad)
            {
                c._elementos.Add(frutas);
            }
            else
            {
                throw new CajonLlenoException("No puede agregar mas frutas");
            }

            return c;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Capacidad: {0}  Cant elementos: {1}  Precio total: {2}\n", this._capacidad, this._elementos.Count, this.PrecioTotal);
            foreach (T item in this._elementos)
            {
                sb.AppendLine(item.ToString());
            }

            return sb.ToString();
        }

        public bool Xml(string path)
        {
            bool retorno = true;
            XmlSerializer xser = new XmlSerializer(typeof(Cajon<T>));
            try
            {
                using (XmlTextWriter var = new XmlTextWriter(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory) + "/Cajon.xml", Encoding.UTF8)) 
                {
                    xser.Serialize(var, this);
                }
            }
            catch (Exception e)
            {
                retorno = false;
                throw;
            }

            return retorno;
        }


    }
}
