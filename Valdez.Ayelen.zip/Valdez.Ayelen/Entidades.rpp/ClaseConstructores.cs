using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace Entidades.rpp
{
 public class ClaseConstructores
  {

    int var1;
    int var2;


    public int Var1
    {
      set
      {
        MessageBox.Show("En prop de solo escritura");
        this.var1 = value;
      }

    }

    public int Var2
    {
      get
      {
        MessageBox.Show("En prop de solo lectura");
        return this.var2;
      }
    }


    static ClaseConstructores()
    {
      MessageBox.Show("En constructor estatico");
    }

    ClaseConstructores(int var1, int var2)
    {
      MessageBox.Show("En constructor parametrizado");

      this.var1 = var1;
      this.var2 = var2;
    }

    public ClaseConstructores() : this(5, 7)
    {
      MessageBox.Show("En constructor por default");
      this.Var1 = 1;
      this.var1 = this.Var2 * 5;
      this.MetodoInstancia();
    }

    public void MetodoInstancia()
    {
      MessageBox.Show("En metodo de instancia");
      MetodoEstatico();
    }

    public static void MetodoEstatico()
    {
      MessageBox.Show("En metodo estatico");
    }
  }
}
