using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.rpp
{
    public class Producto
    {
    #region Atributos
    public string nombre;
    public int stock;
    #endregion

    #region Constructor
    public Producto(string nombre, int stock)
    {
      this.nombre = nombre;
      this.stock = stock;
    }
    #endregion

    #region Operadores
    public static bool operator ==(Producto a, Producto b)
    {

      bool retorno = false;

      try
      {

        if (a.nombre == b.nombre)
        {

          retorno = true;

        }

      }
      catch (NullReferenceException)
      {

        retorno = false;

      }

      return retorno;

    }

    public static bool operator !=(Producto a, Producto b)
    {

      return !(a == b);

    }

    public static int operator ==(Producto[] d, Producto p)
    {

      int retorno = -1;

      for (int i = 0; i < d.Length; i++)
      {

        if (d[i] == p)
        {

          retorno = i;
          break;

        }

      }

      return retorno;

    }

    public static int operator !=(Producto[] d, Producto p)
    {

      return -1;

    }
    #endregion

  }
}
