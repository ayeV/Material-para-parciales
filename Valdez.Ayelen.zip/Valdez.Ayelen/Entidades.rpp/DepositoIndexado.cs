using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.rpp
{
  public class DepositoIndexado
  {
    Producto[] productos;

    #region Constructores
    public DepositoIndexado() : this(3)
    {


    }

    public DepositoIndexado(int cant)
    {
      this.productos = new Producto[cant];
    }
    #endregion

    #region Indexador

    public Producto this[int indice]
    {

      get
      {

        if (indice >= this.productos.GetLength(0) || indice < 0)
          return null;
        else
          return this.productos[indice];
      }
      set
      {
        if (indice >= 0 && indice < this.productos.GetLength(0))
          this.productos[indice] = value;
        else if (indice == this.productos.GetLength(0))
        {

          this.productos = this + indice;
          this[indice] = value;
        }

      }
    }
    #endregion

    #region Operador
    public static Producto[] operator +(DepositoIndexado depo, int indice)
    {
      int i = indice >= depo.productos.GetLength(0) ? ++indice : --indice;

      Producto[] aux = new Producto[i];

      depo.productos.CopyTo(aux, 0);

      return aux;

    }
    #endregion


  }
}
