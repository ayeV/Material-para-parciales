using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.rpp
{
 public class Deposito
  {
    //public Producto[] productos;
    public List<Producto> productos;


    public Deposito() : this(3)
    {

    }

    public Deposito(int cant)
    {
      this.productos = new List<Producto>(cant);

    }

    public static List<Producto> operator +(Deposito a, Deposito b)
    {
      Producto[] auxProductos = new Producto[4];
      Producto auxP;
      int index = 0;
      int indice;

      foreach (Producto i in a.productos)
      {

        if ((auxProductos == i) == -1)
        {

          auxProductos[index] = i;
          index++;
          //if (index == 3)
          //{
          //  break;
          //}
          //else
          //{
          //  index++;
          //}
        }
        else
        {

          indice = (auxProductos == i);
          auxP = new Producto(i.nombre, auxProductos[indice].stock + i.stock);
          auxProductos[indice] = auxP;

        }

      }

      foreach (Producto i in b.productos)
      {

        if ((auxProductos == i) == -1)
        {

          auxProductos[index] = i;
          index++;

        }
        else
        {

          indice = (auxProductos == i);
          auxP = new Producto(i.nombre, auxProductos[indice].stock + i.stock);
          auxProductos[indice] = auxP;

        }

      }

      return auxProductos.ToList();

    }





    public List<Producto> OrdenadoPorStock()
    {


      return this.productos.OrderBy(x => x.stock).ToList();



    }

    public List<Producto> OrdenadoPorNombre()
    {
      
      return this.productos.OrderBy(x => x.nombre).ToList();
  

    }
  }
}
