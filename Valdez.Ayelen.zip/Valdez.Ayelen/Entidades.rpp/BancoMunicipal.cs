using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.rpp
{
  public class BancoMunicipal : BancoProvincial
  {
    public string municipio;

    public BancoMunicipal(BancoProvincial bp, string municipio) : base(bp, bp.provincia)
    {
      this.municipio = municipio;
    }

    public override string Mostrar()
    {
      return base.Mostrar();
    }

    public static implicit operator string(BancoMunicipal banco)
    {
      return banco.ToString();
    }

    public override string ToString()
    {
      return string.Format("Nombre {0} Pais {1} Provincia {2} Municipio {3}", this.nombre, this.pais, this.provincia, this.municipio);
    }
  }
}
