﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
   public class Humano :Animal
    {
        #region Atributos
        string _apellido;
        string _nombre;
        static int _piernas;
        #endregion

        #region Constructores
        static Humano()
        {
            Humano._piernas = 2;
        }

        public Humano(int velocidadMaxima) :base(Humano._piernas,velocidadMaxima)
        {
        }

        public Humano(string nombre, string apellido, int velocidadMaxima) :this(velocidadMaxima)
        {
            this._nombre = nombre;
            this._apellido = apellido;
            
        }
        #endregion

        #region Operadores
        public static bool operator == (Humano h1, Humano h2)
        {
            bool retorno = false;
            if(!object.Equals(h1,null) && !object.Equals(h2,null))
            {
                if(string.Equals(h1._nombre, h2._nombre) && string.Equals(h1._apellido,h2._apellido))
                {
                    retorno = true;
                }
            }
            return retorno;
        }
        public static bool operator !=(Humano h1, Humano h2)
        {
            return !(h1 == h2);
        }

        #endregion

        #region Metodo
        public string MostrarHumano()
        {
            return string.Format("Apellido: {0}, Nombre: {1}", this._apellido, this._nombre);
        }
        #endregion
    }
}
