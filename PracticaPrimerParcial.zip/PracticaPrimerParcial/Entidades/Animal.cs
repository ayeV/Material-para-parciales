﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
   public abstract class Animal
    {
        #region Atributos
        protected int _cantidadPatas;
        protected static Random _distanciaRecorrida;
        protected int _velocidadMaxima;
        #endregion

        #region Propiedades
        public int CantidadPatas
        { get { return this._cantidadPatas; }

            set
            {
               if(value > 0 && value <=4 )
                {
                    this._cantidadPatas = value;
                }
               else
                {
                    this._cantidadPatas = 4;
                }
            }

        }

        public int VelocidadMaxima
        {
            
            set
            {
                if( value > 0 && value <= 60)
                {
                    this._velocidadMaxima = value;
                }
                else
                {
                    this._velocidadMaxima = 60;
                }
            }

            get { return this._velocidadMaxima; }
        }


        private int DistanciaRecorrida
        {
            get
            {
                return Animal._distanciaRecorrida.Next(10, this.VelocidadMaxima);
            }
           
        }
        #endregion

        #region Constructor
        static Animal()
        {
            Animal._distanciaRecorrida = new Random(DateTime.Now.Millisecond);
        }

        public Animal(int cantPatas, int velocidadMaxima)
        {
            this.CantidadPatas = cantPatas;
            this.VelocidadMaxima = velocidadMaxima;

        }
        #endregion

        #region Metodo
        public string MostrarDatos()
        {
            return string.Format("Cantidad patas: {0},Distancia recorrida: {1}, Velocidad maxima: {2}", this.CantidadPatas, this.DistanciaRecorrida, this.VelocidadMaxima);
        }
        #endregion
    }
}
