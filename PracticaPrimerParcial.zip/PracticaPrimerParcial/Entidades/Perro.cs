﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
   public class Perro :Animal
    {
        public enum Razas { Galgo, OvejeroAleman };

        #region Atributos
       static int _patas;
        Razas _raza;
        #endregion
        #region Constructores
        static Perro()
        {
            Perro._patas = 4;
        }

        public Perro(int velocidadMaxima) :base(Perro._patas, velocidadMaxima)
        {

        }

        public Perro(Razas raza, int velocidadMaxima) :this(velocidadMaxima)
        {
            this._raza = raza;
        }
        #endregion

        #region Operadores
        public static bool operator ==(Perro p1, Perro p2)
        {
            bool retorno = false;

            if(!object.Equals(p1,null) && !object.Equals(p2,null))
            {
                if(p1._raza == p2._raza && p1.VelocidadMaxima == p2.VelocidadMaxima)
                {
                    retorno = true;
                }
            }
            return retorno;
        }
        public static bool operator !=(Perro p1, Perro p2)
        {
            return !(p1 == p2);
        }
        #endregion

        #region Metodo
        public string MostrarPerro()
        {
            return string.Format("Raza: {0}", this._raza);
        }

        #endregion
    }
}
