﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
   public class Carrera
    {
        #region Atributos
        List<Animal> _animales;
        int corredoresMax;
        #endregion

        #region Constructores
        Carrera()
        {
            this._animales = new List<Animal>();
        }

        public Carrera(int corredoresMax) :this()
        {
            this.corredoresMax = corredoresMax;
        }
        #endregion

        #region Operadores

        public static bool operator ==(Carrera c, Animal a)
        {
            bool retorno = false;
            if(!object.Equals(c,null) && !object.Equals(a,null))
            {
                foreach(Animal item in c._animales)
                {
                    if(item.GetType() == a.GetType())
                    {
                       if(a is Perro && ((Perro)a == (Perro)item) )
                       {
                            retorno = true;
                            break;
                       }
                       else if(a is Caballo && ((Caballo)a == (Caballo) item))
                       {
                            retorno = true;
                            break;
                       }
                       else if (a is Humano && ((Humano)a == (Humano)item))
                        {
                            retorno = true;
                            break;
                        }


                    }
                }
            }

            return retorno;
        }

        public static bool operator !=(Carrera c, Animal a)
        {
            return !(c == a);
        }

        public static Carrera operator +(Carrera c, Animal a)
        {
            if(!object.Equals(c,null) && !object.Equals(a,null))
            {
                foreach(Animal item in c._animales)
                {
                    if( c ==a)
                    {
                        return c;
                    }
                }

                if(c._animales.Count < c.corredoresMax)
                {
                    c._animales.Add(a);
                }

            }
            return c;
        }

        #endregion

        #region Metodos
        public string MostrarCarrera(Carrera c)
        {
            StringBuilder sb = new StringBuilder();

            if(!object.Equals(c,null))
            {
                sb.AppendLine("-----------------------------------------------------");
                sb.AppendFormat("Cantidad de corredores: {0}", c.corredoresMax);
                sb.AppendLine("");
                int cant = c._animales.Count;
                for(int i= 0;i<cant;i++)
                {
                    sb.AppendLine(this._animales[i].MostrarDatos());
                    if(this._animales[i] is Perro)
                    {
                        sb.AppendLine(((Perro)this._animales[i]).MostrarPerro());
                        sb.AppendLine("");
                        
                    }
                    else if( this._animales[i] is Caballo)
                    {
                        sb.AppendLine(((Caballo)this._animales[i]).MostrarCaballo());
                        sb.AppendLine("");
                    }

                    else if( this._animales[i] is Humano)
                    {
                        sb.AppendLine(((Humano)this._animales[i]).MostrarHumano());
                        sb.AppendLine("");
                    }

                }
                sb.AppendLine("-----------------------------------------------------");
            }
            return sb.ToString();
        }
        #endregion

    }
}
