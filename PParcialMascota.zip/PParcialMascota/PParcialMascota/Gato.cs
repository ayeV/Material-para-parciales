﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PParcialMascota
{
    public class Gato : Mascota
    {
        #region Constructor
        public Gato(string nombre, string raza) : base(nombre, raza)
        {

        }
        #endregion

        #region Operadores
        public static bool operator ==(Gato obj1, Gato obj2)
        {
            bool retorno = false;

            if (!object.Equals(obj1, null) && !object.Equals(obj2, null))
            {
                if (string.Equals(obj1.Nombre, obj2.Nombre) && string.Equals(obj1.Raza, obj2.Raza))
                {
                    retorno = true;
                }
            }
            return retorno;

        }

        public static bool operator !=(Gato obj1, Gato obj2)
        {
            return !(obj1 == obj2);
        }

        #endregion

        #region Metodos

        protected override string Ficha()
        {
            return string.Format("{0} {1}", this.Nombre, this.Raza);
        }

        public override string ToString()
        {
            return this.Ficha();


        }

        public override bool Equals(object obj)
        {
            bool retorno = false;

            if (obj is Gato)
            {
                retorno = (this == (Gato)obj);
            }

            return retorno;

        }
        #endregion

    }
}
