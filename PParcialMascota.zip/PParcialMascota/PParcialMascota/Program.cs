﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PParcialMascota
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Primer parcial mascotas 2º 2018";

            Grupo grupo = new Grupo("Rio", Grupo.TipoManada.Unica);

            Mascota p1 = new Perro("Moro", "Pitbull");
            Perro p2 = new Perro("Julio", "Cruza", 13, false);
            Mascota p3 = new Perro("Ramon", "Salchicha", 2, true);
            Mascota g1 = new Gato("Jose", "Angora");
            Gato g2 = new Gato("Hernan", "Cruza");
            Gato g3 = new Gato("Fer", "Siames");
            Gato g4 = new Gato("Fer", "Siames");



            grupo += p1;
            grupo += p2;
            grupo += p3;
            grupo += g1;
            grupo += g2;
            grupo += g3;
            grupo += g4; //No deberia poder agregarlo

            //Muestro
            Console.WriteLine((string)grupo);

            Console.ReadKey();



            //Quito un elemento y muestro
            grupo -= g3;


            Console.WriteLine((string)grupo);
            Console.ReadLine();


        }
    }
}
