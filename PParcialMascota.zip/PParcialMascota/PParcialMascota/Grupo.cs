﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PParcialMascota
{
    class Grupo
    {
        public enum TipoManada { Unica, Mixta };

        #region Atributos
        List<Mascota> manada;
        string nombre;
        static TipoManada tipo;
        #endregion

        #region Propiedades
        public TipoManada Tipo
        {
            set { Grupo.tipo = value; }
        }
        #endregion

        #region Constructores

        static Grupo()
        {
            Grupo.tipo = TipoManada.Unica;
        }

        private Grupo()
        {
            this.manada = new List<Mascota>();

        }

        public Grupo(string nombre) : this()
        {
            this.nombre = nombre;
        }

        public Grupo(string nombre, TipoManada tipo) : this(nombre)
        {
            this.Tipo = tipo;

        }
        #endregion

        #region Operadores

        public static implicit operator string(Grupo e)
        {
            StringBuilder sb = new StringBuilder();

            if (!object.Equals(e, null))
            {
                sb.AppendFormat("**{0} {1}**", e.nombre, Grupo.tipo);
                sb.AppendLine("\nIntegrantes: ");

                foreach (Mascota item in e.manada)
                {
                    sb.AppendLine(item.ToString());

                }

            }

            return sb.ToString();

        }

        public static bool operator ==(Grupo e, Mascota j)
        {
            bool retorno = false;

            if (!object.Equals(e, null) && !object.Equals(j, null))
            {
                foreach (Mascota item in e.manada)
                {
                    if (j.Equals(item))
                    {
                        retorno = true;
                        break;
                    }
                }

            }

            return retorno;
        }

        public static bool operator !=(Grupo e, Mascota j)
        {
            return !(e == j);
        }

        public static Grupo operator +(Grupo e, Mascota j)
        {
            if (!object.Equals(e, null) && !object.Equals(j, null))
            {

                if (e != j)
                    e.manada.Add(j);

            }
            return e;

        }

        public static Grupo operator -(Grupo e, Mascota j)
        {
            if (!object.Equals(e, null) && !object.Equals(j, null))
            {
                if (e == j)
                {
                    e.manada.Remove(j);
                }
            }
            return e;
        }


        #endregion


    }
}
