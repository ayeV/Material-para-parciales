﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PParcialMascota
{
    public class Perro : Mascota
    {
        #region Atributos
        int edad;
        bool esAlfa;
        #endregion

        #region Propiedades
        public int Edad
        {
            get { return this.edad; }

            set { this.edad = value; }
        }

        public bool EsAlfa
        {
            get { return this.esAlfa; }
            set { this.esAlfa = value; }
        }

        #endregion

        #region Constructores

        public Perro(string nombre, string raza) : base(nombre, raza)
        {
            this.Edad = 0;
            this.EsAlfa = false;
        }

        public Perro(string nombre, string raza, int edad, bool esAlfa) : this(nombre, raza)
        {
            this.Edad = edad;
            this.EsAlfa = esAlfa;
        }
        #endregion

        #region Operadores
        public static explicit operator int(Perro perro)
        {
            return perro.Edad;

        }

        public static bool operator ==(Perro perroj1, Perro perroj2)
        {
            bool retorno = false;

            if (!object.Equals(perroj1, null) && !object.Equals(perroj2, null))
            {
                if ((string.Equals(perroj1.Nombre, perroj2.Nombre) == true) && (string.Equals(perroj1.Raza, perroj2.Raza) == true) && (perroj1.edad == perroj2.edad))
                {
                    retorno = true;
                }
            }

            return retorno;


        }

        public static bool operator !=(Perro perroj1, Perro perroj2)
        {
            return !(perroj1 == perroj2);
        }
        #endregion

        #region Metodos
        protected override string Ficha()
        {
            string retorno;
            if (this.EsAlfa == true)
            {
                retorno = string.Format("{0} {1}, Alfa de la manada, edad {2}", this.Nombre, this.Raza, this.Edad);
            }
            else
            {
                retorno = string.Format("{0} {1} edad {2}", this.Nombre, this.Raza, this.Edad);
            }
            return retorno;

        }

        public override string ToString()
        {
            return this.Ficha();
        }

        public override bool Equals(object obj)
        {
            bool retorno = false;
            if (obj is Perro)
            {
                retorno = (this == (Perro)obj);
            }
            return retorno;
        }
        #endregion
    }
}
