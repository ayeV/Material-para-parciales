using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.RPP
{
  public abstract class Banco
  {
    string _nombre;

    public string Nombre
    {
      get { return this._nombre; }
    }


    public Banco(string nombre)
    {
      this._nombre = nombre;
    }

    public abstract string Mostrar();
    public abstract string Mostrar(Banco b);


  }
}
