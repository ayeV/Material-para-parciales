using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.RPP
{
 public class ClaseConstructores
  {
    private int _param1;
    private int _param2;
    static int _atributoEstatico;

    public int Param1
    {
      get { return this._param1; }
    }
    public int Param2
    {
      set { this._param2 = value; }
    }





    static ClaseConstructores()
    {
      ClaseConstructores._atributoEstatico = 4;
    }

    public ClaseConstructores()
    {

    }
     ClaseConstructores(int param1, int param2)
    {
      this._param1 = param1;
      this.Param2 = param2;
    }

   void MetodoDeInstancia()
    {

    }

    static void MetodoDeClase()
    {

    }

  }
}
