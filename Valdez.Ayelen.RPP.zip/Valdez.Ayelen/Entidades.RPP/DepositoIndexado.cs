using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.RPP
{
  public class DepositoIndexado
  {
    List<Producto> _productos;
    int _capacidad;

    public DepositoIndexado(int capacidad)
    {
      this._capacidad = capacidad;
    }

    public Producto this[int indice]
    {

      get
      {
        if (indice >= 0 && indice < this._capacidad)
        {
          return this._productos[indice];
        }
        else
        {
          return null;
        }

      }

      set
      {
        if (indice >= 0 && indice < this._capacidad)
        {
          this._productos[indice] = value;
        }

      }

    }



  }
}

