using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.RPP
{
 public class Deposito
  {
   public Producto[] productos;
    int _capacidad;

    public Deposito() :this(3)
    {
      
    }

    public Deposito(int capacidad)
    {
      this._capacidad = capacidad;
      this.productos = new Producto[this._capacidad];
    }

    public static bool operator ==(Producto p, Deposito d)
    {
      bool retorno = false;


      for (int i = 0; i < d._capacidad; i++)
      {
        if (d.productos.GetValue(i) != null)
        {

          if (d.productos[i] == p)
          {
            retorno = true;
            break;
          }

        }

      }



      return retorno;

    }

    public static bool operator !=(Producto p, Deposito d)
    {
      return !(p == d);
    }

    public static Deposito operator +(Deposito d, Producto p)
    {
      int index = -1;
      if (p == d)
      {
        index = d.ObtenerIndice(p);
        d.productos[index] += p;

      }
      else
      {
        index = d.ObtenerIndice();
        if (index > -1)
          d.productos[index] = p;
      }
      return d;

    }

    //public static Producto[] operator +(Deposito d1, Deposito d2)
    //{
    //  if(!object.Equals(d1,null) && !object.Equals(d2,null))
    //  {
       
    //  }
    //}



    private int ObtenerIndice()
    {
      int index = -1;
      for (int i = 0; i < this._capacidad; i++)
      {
        if (this.productos.GetValue(i) == null)
        {
          index = i;
          break;

        }

      }
      return index;

    }

    private int ObtenerIndice(Producto p)
    {
      int index = -1;
      int i = 0;
      foreach (Producto item in this.productos)
      {
        if (this.productos.GetValue(i) != null)
        {
          if (p == item)
          {
            index = i;
            break;
          }
        }
        i++;
      }

      return index;
    }
  }
}
