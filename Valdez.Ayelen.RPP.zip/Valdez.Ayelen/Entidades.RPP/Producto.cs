using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.RPP
{
 public class Producto
  {
   public string nombre;
   public int stock;

  


    public Producto(string nombre, int stock)
    {
      this.nombre = nombre;
      this.stock = stock;
    }

    public static bool operator == (Producto p1, Producto p2)
    {
      bool retorno = false;
      if(!object.Equals(p1,null) && !object.Equals(p2,null))
      {
        if(p1.nombre == p2.nombre)
        {
          retorno = true;
        }
      }
      return retorno;
    
    }

    public static bool operator !=(Producto p1, Producto p2)
    {
      return !(p1 == p2);
    }


    public static Producto operator +(Producto t, int cant)
    {
      Producto retorno = new Producto(t.nombre,(t.stock+cant));
      return retorno;

    }

    public static Producto operator +(Producto t1, Producto t2)
    {
      Producto retorno = new Producto(t1.nombre,t1.stock);

      if (t1 == t2)
      {
        retorno = retorno + t2.stock;
      }
      return retorno;
    }
  }
}
