using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.RPP
{
 public class BancoProvincial :Banco
  {
    string _provincia;

    public BancoProvincial(BancoNacional bn, string provincia) :base(bn.Nombre)
    {
      this._provincia = provincia;
    }

    public override string Mostrar()
    {
      return string.Format("{0}", this.Nombre);

    }

    public override string Mostrar(Banco b)
    {
      return string.Format("{0}", ((BancoProvincial)b)._provincia);
    }

  }
}
