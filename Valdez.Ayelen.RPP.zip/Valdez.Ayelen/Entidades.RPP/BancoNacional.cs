using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.RPP
{
  public class BancoNacional : Banco
  {
    string _pais;

    public BancoNacional(string nombre, string pais) : base(nombre)
    {
      this._pais = pais;
    }

    public override string Mostrar()
    {
      return string.Format("{0}", this.Nombre);

    }

    public override string Mostrar(Banco b)
    {
      return string.Format("{0}", ((BancoNacional)b)._pais);
    }


  }
}
