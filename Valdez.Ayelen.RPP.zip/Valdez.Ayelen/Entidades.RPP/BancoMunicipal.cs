using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.RPP
{
  public class BancoMunicipal : Banco
  {
    string _municipio;

    public BancoMunicipal(BancoProvincial bp, string municipio) : base(bp.Nombre)
    {
      this._municipio = municipio;
    }

    public static implicit operator string(BancoMunicipal bm)
    {
      return bm._municipio + bm.Nombre;
    }


    public override string Mostrar()
    {
      return string.Format("{0}", this.Nombre);

    }

    public override string Mostrar(Banco b)
    {
      return string.Format("{0}", ((BancoMunicipal)b)._municipio);
    }

   
  }
}
