using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
  public class Biblioteca
  {
    int _capacidad;
    List<Libro> _libros;

    #region Propiedades
    public double PrecioDeManuales
    {
      get
      {
        return this.ObtenerPrecio(ELibro.Manual);
        
      }

    }

    public double PrecioDeNovelas
    {
      get
      {
        return this.ObtenerPrecio(ELibro.Novela);
      }


    }

    public  double PrecioTotal
    {
      get { return this.ObtenerPrecio(ELibro.Ambos); }


    }
    #endregion

    #region Constructores

    private Biblioteca()
    {
      this._libros = new List<Libro>();
    }

    private Biblioteca(int capacidad) : this()
    {
      this._capacidad = capacidad;
    }
    #endregion

    #region Operadores
    public static implicit operator Biblioteca(int capacidad)
    {

      Biblioteca biblio = new Biblioteca(capacidad);
      return biblio;
    }

    public static bool operator ==(Biblioteca e, Libro l)
    {
      bool retorno = false;

      for (int i = 0; i < e._libros.Count; i++)
      {
        if (l == e._libros[i])
        {
          retorno = true;
          break;
        }
      }

      return retorno;
    }

    public static bool operator !=(Biblioteca e, Libro l)
    {
      return !(e == l);
    }

    public static Biblioteca operator +(Biblioteca e, Libro l)
    {
      foreach(Libro item in e._libros)
      {
        if(e == l)
        {
          Console.WriteLine("El libro ya esta en la biblioteca");
          return e;
        }
      }

      if(e._libros.Count < e._capacidad)
      {
        e._libros.Add(l);
      }
      else
      {
        Console.WriteLine("No hay mas lugar en la biblioteca");
      }

      return e;

    }

    #endregion

    #region Metodos

    double ObtenerPrecio(ELibro tipoLibro)
    {
      double precioTotal = 0;
      double precioManual = 0;
      double precioNovela = 0;
        
      int contNovelas = 0;
      int contManuales = 0;
      

      foreach (Libro item in this._libros)
      {
        if(item is Manual)
        {
          contManuales++;
        }
        else if(item is Novela)
        {
          contNovelas++;
        }
       

      }

      switch(tipoLibro)
      {
        case ELibro.Manual:
          foreach (Manual item in this._libros)
          {
            if (item is Manual)
            {
              precioManual = item;
              break;
            }
          }
          precioTotal = contManuales * precioManual;
          break;

        case ELibro.Novela:
          foreach (Novela item in this._libros)
          {
            if (item is Novela)
            {
              precioNovela = item;
              break;
            }
          }
          precioTotal = contNovelas * precioNovela;
          break;

        case ELibro.Ambos:
          precioTotal = precioNovela + precioManual;
          break;

      }

      return precioTotal;


    }

    public static string Mostrar(Biblioteca e)
    {
      StringBuilder sb = new StringBuilder();
      
      sb.AppendFormat("Capacidad de la biblioteca: {0}", e._capacidad);
      sb.AppendLine("");
      foreach(Libro item in e._libros)
      {
        if(item is Manual)
        {
          sb.AppendLine("Manual");
        }
        else if(item is Novela)
        {
          sb.AppendLine("Novela");
        }

      }

      return sb.ToString();
    }

    #endregion
  }
}
