﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Parcial
{
   public class Camion:Vehiculo
    {
        float _tara;

        public Camion(string patente, EMarcas marca, float tara, byte cantR) :base(patente,cantR,marca)
        {
            this._tara = tara;
        }

        public Camion(Vehiculo vehiculo, float tara) :base(vehiculo.Patente,vehiculo.CantRuedas,vehiculo.Marca)
        {
            this._tara = tara;
            
        }


        protected override string Mostrar()
        {
            return string.Format( base.Mostrar() + "Tara: {0}", this._tara);
        }

        public override string ToString()
        {
            return this.Mostrar();
        }

    }
}
