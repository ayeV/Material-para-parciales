﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Parcial
{
   public class Lavadero
    {
        List<Vehiculo> _vehiculos;
        static float _precioAuto;
        static float _precioCamion;
        static float _precioMoto;
        string _razonSocial;

        Lavadero()
        {
            this._vehiculos = new List<Vehiculo>();
        }

      static Lavadero() 
        {
            Random rnm = new Random();
            Lavadero._precioAuto = rnm.Next(150,565);
            Lavadero._precioCamion = rnm.Next(150,565);
            Lavadero._precioMoto = rnm.Next(150,565);
        }

        public Lavadero(string razonSocial) :this()
        {
            this._razonSocial = razonSocial;
        }

        public  string  LavaderoToString
        {
            get

            {
                string retorno = "";
                retorno =  this._razonSocial + Lavadero._precioAuto + Lavadero._precioCamion + Lavadero._precioMoto;
                retorno = string.Format("Razon social: {0}, Precio auto: {1}, Precio Camion: {2}, Precio Moto: {3}",this._razonSocial,Lavadero._precioAuto,Ñ)
                foreach (Vehiculo item in this._vehiculos)
                {
                    
                     retorno += item.ToString();
                }

                return retorno;
               
            }

        }

        public List<Vehiculo> Vehiculos
        {
            get { return this._vehiculos; }
        }

        public double MostrarTotalFacturado(EVehiculos vehiculo)
        {
            double ganancia = 0;
            
            int contAutos = 0;
            int contCamiones = 0;
            int contMotos = 0;

            foreach (Vehiculo item in l.Vehiculos)
            {
                if (item is Auto)
                {
                    contAutos++;
                }
                else if (item is Camion)
                {
                    contCamiones++;

                }
                else if (item is Moto)
                {
                    contMotos++;
                }
            }

            foreach (Vehiculo item in this.Vehiculos)
            {
               switch(vehiculo)
                {
                    case EVehiculos.Auto:
                        if(item is Auto)
                        {
                            ganancia =Lavadero._precioAuto++;
                        }
                        break;

                    case EVehiculos.Camion:
                        if(item is Camion)
                        {
                          ganancia=  Lavadero._precioCamion++;
                        }
                        break;
                    case EVehiculos.Moto:
                        if(item is Moto)
                        {
                           ganancia = Lavadero._precioMoto++;
                        }
                        break;

                }
                    
            }

            return ganancia;

        }

        public double MostrarTotalFacturado()
        {
        
            return  this.MostrarTotalFacturado(EVehiculos.Auto) + this.MostrarTotalFacturado(EVehiculos.Camion) + this.MostrarTotalFacturado(EVehiculos.Moto);
           
        }

        public static bool operator == (Lavadero l, Vehiculo v)
        {
            bool retorno = false;
        
            return retorno;

        }
        public static bool operator !=(Lavadero l, Vehiculo v)
        {
            return !(l == v);
        }

        public static int operator ==(Vehiculo v, Lavadero l)
        {

            int index = -1;
            foreach(Vehiculo item in l.Vehiculos)
            {
                index++;
                if(l == item)
                {
                    break;
                }
            }

            if(l.Vehiculos.Count == index)
            {
                index = -1;
            }

            return index;
        }

        public static int operator !=(Vehiculo v, Lavadero l)
        {
            return v == l;
        }

        public static Lavadero operator + (Lavadero l, Vehiculo v)
        {
            int index = v == l;
            if (v == )
            {
                p._colores[index] += t;
            }
            else
            {
                int cant = p._colores.Count;
                if (cant < p._cantMaximaElementos)
                {
                    p._colores.Add(t);

                }

            }

            return p;
        }

        public static Lavadero operator -(Lavadero l, Vehiculo v)
        {

        }


    }
}
