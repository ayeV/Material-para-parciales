﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Parcial
{
   public class Lavadero
    {
        List<Vehiculo> _vehiculos;
        static float _precioAuto;
        static float _precioCamion;
        static float _precioMoto;
        string _razonSocial;

        Lavadero()
        {
            this._vehiculos = new List<Vehiculo>();
        }

      static Lavadero() 
        {
            Random rnm = new Random();
            Lavadero._precioAuto = rnm.Next(150,565);
            Lavadero._precioCamion = rnm.Next(150,565);
            Lavadero._precioMoto = rnm.Next(150,565);
        }

        public Lavadero(string razonSocial) :this()
        {
            this._razonSocial = razonSocial;
        }

        public  string  LavaderoToString
        {
            get

            {
                string retorno = "";
                
                retorno = string.Format("Razon social: {0}\n *Precio auto: {1}\n *Precio Camion: {2}\n *Precio Moto: {3}\n", this._razonSocial, Lavadero._precioAuto, Lavadero._precioCamion, Lavadero._precioMoto);
                foreach (Vehiculo item in this._vehiculos)
                {
                    
                     retorno += item.ToString();
                }

                return retorno;
               
            }

        }

        public List<Vehiculo> Vehiculos
        {
            get { return this._vehiculos; }
        }

        public double MostrarTotalFacturado(EVehiculos vehiculo)
        {
            double ganancia = 0;
            
            int contAutos = 0;
            int contCamiones = 0;
            int contMotos = 0;

            foreach (Vehiculo item in this._vehiculos)
            {
                if (item is Auto)
                {
                    contAutos++;
                }
                else if (item is Camion)
                {
                    contCamiones++;

                }
                else if (item is Moto)
                {
                    contMotos++;
                }
            }

            
               switch(vehiculo)
                {
                    case EVehiculos.Auto:
                       
                            ganancia = contAutos*Lavadero._precioAuto;
                        
                        break;

                    case EVehiculos.Camion:
                       
                          ganancia = contCamiones*Lavadero._precioCamion;
                        
                        break;
                    case EVehiculos.Moto:
                       
                           ganancia = contMotos*Lavadero._precioMoto;
                        
                        break;

                }
                    
            

            return ganancia;

        }

        public double MostrarTotalFacturado()
        {
        
            return  this.MostrarTotalFacturado(EVehiculos.Auto) + this.MostrarTotalFacturado(EVehiculos.Camion) + this.MostrarTotalFacturado(EVehiculos.Moto);
           
        }

        public static bool operator == (Lavadero l, Vehiculo v)
        {
            bool retorno = false;
            //llama al otro ==

            
            if((v == l) != -1)
            {
                retorno = true;
            }
        
            return retorno;

        }
        public static bool operator !=(Lavadero l, Vehiculo v)
        {
            return !(l == v);
        }

        public static int operator ==(Vehiculo v, Lavadero l)
        {

            int index = -1;
            for(int i= 0;i<l._vehiculos.Count;i++)
            {
                if( v == l._vehiculos[i])
                {
                    index = i;
                    break;
                }
            }

            return index;
        }

        public static int operator !=(Vehiculo v, Lavadero l)
        {
            return 0;
        }

        public static Lavadero operator + (Lavadero l, Vehiculo v)
        {
           if( l != v)
            {
                l._vehiculos.Add(v);
            }
            return l;

        }

        public static Lavadero operator -(Lavadero l, Vehiculo v)
        {
            foreach (Vehiculo item in l._vehiculos)
            {
                if (l == v)
                {
                    l._vehiculos.Remove(v);
                    break;
                }
            }
            return l;



        }

        public static int OrdenarVehiculosPorPatente(Vehiculo v1, Vehiculo v2)
        {
            int retorno;

            if(string.Compare(v1.Patente,v2.Patente) == 0)
            {
                retorno = 0;
            }
            else if(string.Compare(v1.Patente,v2.Patente) < 0)
            {
                retorno = -1;
            }
            else
            {
                retorno = 1;
            }

            return retorno;

        }

        public int OrdenarVehiculosPorMarca(Vehiculo v1, Vehiculo v2)
        {
            int retorno = 0;

            if(v1.Marca == v2.Marca )
            {
                retorno = 0;
            }
            else if(v1.Marca > v2.Marca)
            {
                retorno = 1;
            }
            else if(v1.Marca<v2.Marca)
            {
                retorno = -1;
            }

            return retorno;
        }

    }
}
