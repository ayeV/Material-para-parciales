﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Parcial
{
  public  class Moto :Vehiculo
    {
        float _cilindrada;

        public Moto(string patente, EMarcas marca, float cilindrada, byte cantR) :base(patente,cantR,marca)
        {
            this._cilindrada = cilindrada;
        }

        public Moto(EMarcas marca, float cilindrada,string patente, byte cantRuedas) :this(patente,marca,cilindrada,cantRuedas)
        {
           
        }

        protected override string Mostrar()
        {
            return string.Format(base.Mostrar() + "Cilindrada: {0}", this._cilindrada);
        }

        public override string ToString()
        {
            return this.Mostrar();
        }


    }

}
