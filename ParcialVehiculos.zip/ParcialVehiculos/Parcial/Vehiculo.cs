﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Parcial
{
    

      public class Vehiculo
    {
       

        #region Atributos
        protected string _patente;
        protected Byte _cantRuedas;
        protected EMarcas _marca;
        #endregion

        #region Propiedades
        public EMarcas Marca
        {
            get { return this._marca; }
        }

        public string Patente
        {
            get { return this._patente; }

        }

        public Byte CantRuedas
        {
            get { return this._cantRuedas; }
            set { this._cantRuedas = value; }

        }

        #endregion

        #region Constructor
        public Vehiculo(string patente, Byte cantRuedas, EMarcas marca)
        {
            this._patente = patente;
            this._cantRuedas = cantRuedas;
            this._marca = marca;
        }
        #endregion

        #region Sobrecargas
        public static bool operator == (Vehiculo v1, Vehiculo v2 )
        {
            bool retorno = false;

            if(!object.Equals(v1,null) && !object.Equals(v2,null))
            {
                if(v1.Marca == v2.Marca && v1.Patente == v2.Patente)
                {
                    retorno = true;
                }
            }

            return retorno;
        }

        public static bool operator !=(Vehiculo v1, Vehiculo v2)
        {
            return !(v1 == v2);
        }
        #endregion

        #region Metodos
        protected virtual string Mostrar()
        {
            return string.Format(" Patente: {0} | Cant ruedas: {1} | Marca: {2}", this._patente, this._cantRuedas, this._marca);
        }

        public override string ToString()
        {
            return this.Mostrar();
        }
        #endregion
    }
}
