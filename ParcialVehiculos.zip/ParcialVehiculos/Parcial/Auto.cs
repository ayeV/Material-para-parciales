﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Parcial
{
  public  class Auto : Vehiculo
    {

        #region Atributos
        protected int _cantidadAsientos;

        #endregion

        public Auto(string patente, EMarcas marca, int cantAsientos, byte cantR) : base(patente, cantR, marca)
        {
            this._cantidadAsientos = cantAsientos;
        }

        public Auto(string patente, EMarcas marca, int cantAsientos) : this(patente,marca,cantAsientos, 4)
        {
           
        }

        protected override string Mostrar()
        {
            return string.Format(base.Mostrar()+"Cant asientos: {0}", this._cantidadAsientos);
        }

        public override string ToString()
        {
            return this.Mostrar();
        }

    }
}
