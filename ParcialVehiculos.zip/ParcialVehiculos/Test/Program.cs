﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Parcial;
namespace Test
{
    class Program
    {
        static void Main(string[] args)
        {
            Lavadero lavadero = new Lavadero("Lava-autos");

            Auto a1 = new Auto("A1", EMarcas.Fiat, 4);
            Auto a2 = new Auto("P2", EMarcas.Honda, 4, 4);
            Vehiculo c1 = new Vehiculo("C1", 5, EMarcas.Iveco);
            Camion camion1 = new Camion(c1, 512);
            Camion camion2 = new Camion("G5", EMarcas.Scania, (float)45.2, 16);
            Moto m1 = new Moto(EMarcas.Zanella, (float)44.5, "MMA", 2);
            Moto m2 = new Moto(EMarcas.Zanella, (float)44.5, "MMA", 2);
            Moto m3 = new Moto("RRR", EMarcas.Honda, 4522, 3);

            lavadero += a1;
            lavadero += a2;
            lavadero += camion1;
            lavadero += camion2;
            lavadero += m1;
            lavadero += m2;
            lavadero += m3;


            Console.Write(lavadero.LavaderoToString);
            //Muestro facturacion

            Console.WriteLine("Facturacion total: {0}", lavadero.MostrarTotalFacturado());
            Console.WriteLine("Facturacion autos: {0}\n Facturacion Camiones:{1}\n Facturacion motos:{2}", lavadero.MostrarTotalFacturado(EVehiculos.Auto), lavadero.MostrarTotalFacturado(EVehiculos.Camion), lavadero.MostrarTotalFacturado(EVehiculos.Moto));
            Console.ReadKey();
            Console.Clear();

            //quito un elemento y muestro

            lavadero -= a1;
            Console.WriteLine("Quito el primer elemento");
            Console.WriteLine(lavadero.LavaderoToString);
            Console.ReadKey();

            //ordeno por marca
            //No ordena bien las marcas, la puta madre
            lavadero.Vehiculos.Sort(lavadero.OrdenarVehiculosPorMarca);
            Console.WriteLine(lavadero.LavaderoToString);
            Console.ReadKey();

            //ordeno por patente

            lavadero.Vehiculos.Sort(Lavadero.OrdenarVehiculosPorPatente);
            Console.WriteLine(lavadero.LavaderoToString);
            Console.ReadKey();

            
            Console.ReadLine();
        }
    }
}
